![](.\screens\java.ico)

   # Java

## wir legen den Path zur Java.exe fest :

```powershell
>> terminal

   $env:PATH += ";C:\working-directory\jdk\JDK21\jdk-21.0.2\bin\"

```
.

```powershell
>> terminal # wir geben aus, ob der vorherige Befehl ohne Fehler abgeschlossen wurde!

   $?

```
.


![](.\screens\cmd.png)

.
## Wir führen die App aus


```js
>> terminal 

   java App

```

![](.\screens\App.png)

```js
>> terminal #wir erzeugen die JAR-Datei


   jar --create --file HelloWorld.jar --verbose --main-class App -C . . -C C:\working-directory\jdk\JDK22 .
```
.

```js
>> terminal # wir prüfen , ob der Befehl ausgeführt worden ist

   $?

```
.

```js
>> terminal # 

   java -jar HelloWorld.jar

```
.

