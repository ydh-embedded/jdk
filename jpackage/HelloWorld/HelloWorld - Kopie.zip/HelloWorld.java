


	import javax.swing.* 	;

	public class HelloWorld {

		public static void main(String[] args) {

			JOptionPane.showMessageDialog( null , "Hallo Welt!") 	;
		}
	}


